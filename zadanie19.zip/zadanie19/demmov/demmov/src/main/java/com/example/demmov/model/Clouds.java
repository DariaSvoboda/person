package com.example.demmov.model;
import lombok.*;

@NoArgsConstructor @AllArgsConstructor @Data
public class Clouds {
    private int all;
}