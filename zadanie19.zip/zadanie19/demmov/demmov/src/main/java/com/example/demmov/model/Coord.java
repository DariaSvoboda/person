package com.example.demmov.model;

import lombok.*;

@NoArgsConstructor @AllArgsConstructor @Data
public class Coord {
    private double lon;
    private double lat;
}