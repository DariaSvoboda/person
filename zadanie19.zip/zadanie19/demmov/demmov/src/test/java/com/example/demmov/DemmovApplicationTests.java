package com.example.demmov;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemmovApplicationTests {

	@Test
	void contextLoads() {
	}

}
