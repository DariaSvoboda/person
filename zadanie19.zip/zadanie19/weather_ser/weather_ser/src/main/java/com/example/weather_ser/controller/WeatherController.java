package com.example.weather_ser.controller;

import com.example.weather_ser.model.Weather;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/weather")
public class WeatherController {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${weather.api.key}")
    private String key;

    @GetMapping
    public Weather getWeather(@RequestParam double lat, @RequestParam double lon) {
        String url = "https://api.openweathermap.org/data/2.5/weather?lat=" + lat + "&lon=" + lon + "&appid=" + key + "&units=metric";

        Map response = restTemplate.getForObject(url, Map.class);
        Map main = (Map) response.get("main");
        List weatherList = (List) response.get("weather");
        Map weatherData = (Map) weatherList.get(0);

        return new Weather(
                Double.parseDouble(main.get("temp").toString()),
                weatherData.get("description").toString()
        );
    }
}