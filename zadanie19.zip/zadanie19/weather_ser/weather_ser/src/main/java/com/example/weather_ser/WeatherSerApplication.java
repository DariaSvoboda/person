package com.example.weather_ser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherSerApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeatherSerApplication.class, args);
	}

}
