package com.example.weather_ser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherSerApplicationTests {

	@Test
	void contextLoads() {
	}

}
