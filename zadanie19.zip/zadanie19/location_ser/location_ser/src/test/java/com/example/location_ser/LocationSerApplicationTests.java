package com.example.location_ser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocationSerApplicationTests {

	@Test
	void contextLoads() {
	}

}
