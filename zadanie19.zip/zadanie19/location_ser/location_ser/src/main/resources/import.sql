INSERT INTO location (id, name, lat, lon) VALUES (1, 'Moscow', 55.7558, 37.6173);
INSERT INTO location (id, name, lat, lon) VALUES (2, 'Saint Petersburg', 59.9343, 30.3351);