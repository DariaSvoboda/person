package com.example.person_ser.dto;

import lombok.Data;

@Data
public class Location {
    private double lat;
    private double lon;
}
