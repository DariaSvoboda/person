package com.example.person_ser.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Person {
    @Id
    private int id;
    @NonNull
    private String name;
    @NonNull
    private String location;

    public Person(String name, String location) {
        this.name = name;
        this.location = location;
    }
}