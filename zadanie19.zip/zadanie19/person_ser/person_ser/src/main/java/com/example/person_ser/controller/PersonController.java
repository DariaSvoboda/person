package com.example.person_ser.controller;

import com.example.person_ser.model.Person;
import com.example.person_ser.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/person")
public class PersonController {
    @Autowired private PersonRepository repository;
    @Autowired private RestTemplate restTemplate;

    @GetMapping("/{id}/weather")
    public Map<String, Object> getWeather(@PathVariable int id) {
        Person person = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Person not found"));

        String locationUrl = "http://localhost:8081/location/" + person.getLocation();
        Map<?, ?> location = restTemplate.getForObject(locationUrl, Map.class);

        if (location == null) throw new RuntimeException("Location service returned nothing");

        double lat = Double.parseDouble(location.get("lat").toString());
        double lon = Double.parseDouble(location.get("lon").toString());

        String weatherUrl = "http://localhost:8082/weather?lat=" + lat + "&lon=" + lon;
        Map<?, ?> weather = restTemplate.getForObject(weatherUrl, Map.class);

        return Map.of("person", person, "location", location, "weather", weather);
    }
    @GetMapping("/{id}")
    public ResponseEntity<Person> findById(@PathVariable int id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    @GetMapping
    public Iterable<Person> findAll() { return repository.findAll(); }

    @PostMapping
    public Person save(@RequestBody Person person) { return repository.save(person); }
}