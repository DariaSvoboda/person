package com.example.person_ser.dto;

import lombok.Data;

@Data
public class Weather {
    private double temp;
    private String description;
}
