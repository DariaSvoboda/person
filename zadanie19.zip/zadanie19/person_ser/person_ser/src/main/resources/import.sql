INSERT INTO person (id, name, location) VALUES (1, 'Ivan', 'Moscow');
INSERT INTO person (id, name, location) VALUES (2, 'Oleg', 'Saint Petersburg');