package com.example.person_ser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonSerApplicationTests {

	@Test
	void contextLoads() {
	}

}
